#!/usr/bin/env python3
"""Halka share card — two crossed stadium rings matching the splash mark."""

from __future__ import annotations

import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

OUT_PNG = Path("/workspace/.grok/og-raw.png")
FONT = "/workspace/.grok/Outfit-SemiBold.ttf"

BLUE = (43, 123, 255, 255)  # #2B7BFF
GRAY = (200, 200, 200, 255)  # #C8C8C8
WHITE = (255, 255, 255, 255)

# App mark (link-flow-logo.tsx) in 400-space, then scaled onto the card.
A, B, STROKE, ANGLE_DEG = 94, 23, 30, 39
MARK_SIZE = 400

SCALE = 4
W, H = 1200 * SCALE, 630 * SCALE


def stadium_ring(scale: float, color: tuple[int, int, int, int], angle_deg: float) -> Image.Image:
    """Stroke a stadium whose centerline matches the app (a, b), then rotate."""
    stroke = max(2, int(round(STROKE * scale)))
    # Outer rounded-rect of a true stadium: height = 2b + stroke, width = 2a + 2b + stroke
    outer_h = int(round((2 * B + STROKE) * scale))
    outer_w = int(round((2 * A + 2 * B + STROKE) * scale))
    pad = stroke + 4
    img = Image.new("RGBA", (outer_w + pad * 2, outer_h + pad * 2), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle(
        [pad, pad, pad + outer_w - 1, pad + outer_h - 1],
        radius=outer_h // 2,
        outline=color,
        width=stroke,
    )
    return img.rotate(angle_deg, resample=Image.Resampling.BICUBIC, expand=True)


def paste_center(base: Image.Image, layer: Image.Image, cx: float, cy: float) -> None:
    x = int(round(cx - layer.width / 2))
    y = int(round(cy - layer.height / 2))
    base.alpha_composite(layer, (x, y))


def draw_tracked(
    draw: ImageDraw.ImageDraw,
    text: str,
    cx: float,
    y: float,
    font: ImageFont.FreeTypeFont,
    fill: tuple[int, int, int, int],
    tracking: int,
) -> tuple[int, int, int, int]:
    widths = [draw.textbbox((0, 0), ch, font=font)[2] - draw.textbbox((0, 0), ch, font=font)[0] for ch in text]
    total = sum(widths) + tracking * (len(text) - 1)
    x = cx - total / 2
    top, bottom = 10**9, -10**9
    for ch, w in zip(text, widths):
        bbox = draw.textbbox((x, y), ch, font=font)
        top = min(top, bbox[1])
        bottom = max(bottom, bbox[3])
        draw.text((x, y), ch, font=font, fill=fill)
        x += w + tracking
    return int(cx - total / 2), int(top), int(cx + total / 2), int(bottom)


def render_card() -> Image.Image:
    canvas = Image.new("RGBA", (W, H), WHITE)

    # Mark ~300px on the 1200 canvas
    mark_px = 300 * SCALE
    s = mark_px / MARK_SIZE
    mx, my = W / 2, H * 0.36

    blue = stadium_ring(s, BLUE, -ANGLE_DEG)
    gray = stadium_ring(s, GRAY, ANGLE_DEG)

    # Soft contact shadow
    shadow_col = (200, 200, 200, 255)
    sh_b = stadium_ring(s, shadow_col, -ANGLE_DEG)
    sh_g = stadium_ring(s, shadow_col, ANGLE_DEG)
    shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    paste_center(shadow, sh_b, mx, my)
    paste_center(shadow, sh_g, mx, my)
    r, g, b, a = shadow.split()
    a = a.point(lambda p: int(p * 0.16))
    shadow = Image.merge(
        "RGBA",
        (r.point(lambda _: 200), g.point(lambda _: 200), b.point(lambda _: 200), a),
    )
    canvas.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(16)), (0, 8))

    blue_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    paste_center(blue_layer, blue, mx, my)
    gray_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    paste_center(gray_layer, gray, mx, my)

    canvas.alpha_composite(blue_layer)
    canvas.alpha_composite(gray_layer)

    # Weave: blue over gray at the right-hand crossing (app uses the rightmost hit).
    # Crossing sits on the +x axis of the mark, slightly below center for the
    # lower-right stroke crossing of the two rings.
    hit_x = mx + 0.22 * mark_px
    hit_y = my
    mask = Image.new("L", (W, H), 0)
    md = ImageDraw.Draw(mask)
    rr = int(0.09 * mark_px)
    md.ellipse([hit_x - rr, hit_y - rr, hit_x + rr, hit_y + rr], fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(3))
    over = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    over.paste(blue_layer, (0, 0), mask)
    canvas.alpha_composite(over)

    draw = ImageDraw.Draw(canvas)
    font = ImageFont.truetype(FONT, 160 * SCALE)
    tracking = int(22 * SCALE)
    scratch = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    measured = draw_tracked(ImageDraw.Draw(scratch), "Halka", W / 2, 0, font, BLUE, tracking)
    target_top = H * 0.62
    title_y = target_top - measured[1]
    box = draw_tracked(draw, "Halka", W / 2, title_y, font, BLUE, tracking)
    print(
        "title_1x",
        tuple(round(v / SCALE) for v in box),
        "width_frac",
        round((box[2] - box[0]) / W, 3),
        "y_frac",
        round(box[1] / H, 3),
        round(box[3] / H, 3),
    )
    return canvas.resize((1200, 630), Image.Resampling.LANCZOS).convert("RGB")


def main() -> None:
    card = render_card()
    OUT_PNG.parent.mkdir(parents=True, exist_ok=True)
    card.save(OUT_PNG, "PNG")
    print(f"wrote {OUT_PNG} {card.size}")


if __name__ == "__main__":
    main()
