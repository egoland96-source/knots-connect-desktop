#!/usr/bin/env python3
"""Generate a 2:1 Halka share card via the xAI Images API."""

from __future__ import annotations

import base64
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

OUT = Path("/workspace/.grok/og-api-raw.png")

PROMPT = (
    "Premium brand identity share card on a seamless pure white studio backdrop. "
    "Centered in the frame: a physical logo sculpture of two interlocking stadium-shaped "
    "chain links forming an infinity mark — the left racetrack ring is glossy vivid blue "
    "#2B7BFF, the right racetrack ring is brushed silver-gray #C8C8C8, each passing through "
    "the other like a chain. Soft diffused studio lighting and a faint contact shadow, "
    "generous empty margins on every side. Directly below the sculpture, centered, the word "
    '"Halka" in clean geometric sans-serif, the same vivid blue, lettering spanning about '
    "half the frame width, comfortable space from every edge."
)


def main() -> int:
    key = os.environ.get("XAI_API_KEY", "").strip()
    if not key:
        print("no XAI_API_KEY", file=sys.stderr)
        return 2

    body = {
        "model": "grok-imagine-image-quality",
        "prompt": PROMPT,
        "n": 1,
        "aspect_ratio": "2:1",
        "response_format": "b64_json",
    }
    req = urllib.request.Request(
        "https://api.x.ai/v1/images/generations",
        data=json.dumps(body).encode(),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            payload = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        err = e.read().decode()[:800]
        print(f"HTTP {e.code}: {err}", file=sys.stderr)
        # fallback model
        body["model"] = "grok-imagine-image-2.0"
        req = urllib.request.Request(
            "https://api.x.ai/v1/images/generations",
            data=json.dumps(body).encode(),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                payload = json.loads(resp.read().decode())
        except Exception as e2:
            print(f"fallback failed: {type(e2).__name__}", file=sys.stderr)
            return 1
    except Exception as e:
        print(f"request failed: {type(e).__name__}: {e}", file=sys.stderr)
        return 1

    data = payload.get("data") or []
    if not data:
        print(f"empty data keys={list(payload.keys())}", file=sys.stderr)
        return 1
    item = data[0]
    b64 = item.get("b64_json") or item.get("b64")
    if b64:
        OUT.write_bytes(base64.b64decode(b64))
        print(f"wrote {OUT} bytes={OUT.stat().st_size}")
        return 0
    url = item.get("url")
    if url:
        with urllib.request.urlopen(url, timeout=60) as resp:
            OUT.write_bytes(resp.read())
        print(f"wrote {OUT} from url bytes={OUT.stat().st_size}")
        return 0
    print(f"no image in item keys={list(item.keys())}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
