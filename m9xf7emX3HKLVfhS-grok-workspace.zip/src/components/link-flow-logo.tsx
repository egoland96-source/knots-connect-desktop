import { useEffect, useRef } from "react";

type Pt = { x: number; y: number };

const BLUE = "#2B7BFF";
const GRAY = "#C8C8C8";
const TRACK = "#E8E8E8";
const SIZE = 400;
const CX = 200;
const CY = 200;
const A = 94;
const B = 23;
const ANGLE = (39 * Math.PI) / 180;
const STROKE = 30;
const STEPS = 48;
const CYCLE_MS = 4800;

function rot(x: number, y: number, ang: number): Pt {
  const c = Math.cos(ang);
  const s = Math.sin(ang);
  return { x: x * c - y * s, y: x * s + y * c };
}

function stadium(a: number, b: number, ang: number, cx: number, cy: number): Pt[] {
  const pts: Pt[] = [];
  const push = (x: number, y: number) => {
    const p = rot(x, y, ang);
    pts.push({ x: p.x + cx, y: p.y + cy });
  };
  for (let i = 0; i < STEPS; i++) {
    const t = i / STEPS;
    push(-a + 2 * a * t, b);
  }
  for (let i = 0; i <= STEPS; i++) {
    const t = i / STEPS;
    const th = Math.PI / 2 - Math.PI * t;
    push(a + b * Math.cos(th), b * Math.sin(th));
  }
  for (let i = 0; i < STEPS; i++) {
    const t = i / STEPS;
    push(a - 2 * a * t, -b);
  }
  for (let i = 0; i <= STEPS; i++) {
    const t = i / STEPS;
    const th = -Math.PI / 2 - Math.PI * t;
    push(-a + b * Math.cos(th), b * Math.sin(th));
  }
  return pts;
}

function segIntersect(p1: Pt, p2: Pt, q1: Pt, q2: Pt): Pt | null {
  const rx = p2.x - p1.x;
  const ry = p2.y - p1.y;
  const sx = q2.x - q1.x;
  const sy = q2.y - q1.y;
  const den = rx * sy - ry * sx;
  if (Math.abs(den) < 1e-9) return null;
  const t = ((q1.x - p1.x) * sy - (q1.y - p1.y) * sx) / den;
  const u = ((q1.x - p1.x) * ry - (q1.y - p1.y) * rx) / den;
  if (t < 1e-6 || t > 1 - 1e-6 || u < 1e-6 || u > 1 - 1e-6) return null;
  return { x: p1.x + t * rx, y: p1.y + t * ry };
}

function insertPoint(loop: Pt[], hit: Pt, segIdx: number): Pt[] {
  const out: Pt[] = [];
  for (let i = 0; i < loop.length; i++) {
    out.push(loop[i]);
    if (i === segIdx) out.push({ x: hit.x, y: hit.y });
  }
  return out;
}

function closestHit(blue: Pt[], gray: Pt[]): { p: Pt; bi: number; gi: number } {
  const hits: { p: Pt; bi: number; gi: number }[] = [];
  for (let i = 0; i < blue.length; i++) {
    const a1 = blue[i];
    const a2 = blue[(i + 1) % blue.length];
    for (let j = 0; j < gray.length; j++) {
      const b1 = gray[j];
      const b2 = gray[(j + 1) % gray.length];
      const p = segIntersect(a1, a2, b1, b2);
      if (p) hits.push({ p, bi: i, gi: j });
    }
  }
  const clustered: { p: Pt; bi: number; gi: number }[] = [];
  for (const h of hits) {
    if (!clustered.some((c) => Math.hypot(c.p.x - h.p.x, c.p.y - h.p.y) < 5)) {
      clustered.push(h);
    }
  }
  clustered.sort((a, b) => b.p.x - a.p.x);
  return clustered[0] ?? { p: { x: CX, y: CY }, bi: 0, gi: 0 };
}

function rotateTo(loop: Pt[], idx: number): Pt[] {
  const n = loop.length;
  const out: Pt[] = [];
  for (let i = 0; i <= n; i++) out.push(loop[(idx + i) % n]);
  return out;
}

function cumlen(pts: Pt[]): { lens: number[]; total: number } {
  const lens = [0];
  let total = 0;
  for (let i = 1; i < pts.length; i++) {
    total += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
    lens.push(total);
  }
  return { lens, total };
}

function pointAt(pts: Pt[], lens: number[], total: number, d: number): Pt {
  const t = ((d % total) + total) % total;
  let i = 0;
  while (i < lens.length - 2 && lens[i + 1] < t) i++;
  const span = lens[i + 1] - lens[i] || 1;
  const u = (t - lens[i]) / span;
  return {
    x: pts[i].x + (pts[i + 1].x - pts[i].x) * u,
    y: pts[i].y + (pts[i + 1].y - pts[i].y) * u,
  };
}

function drawSubpath(
  ctx: CanvasRenderingContext2D,
  pts: Pt[],
  lens: number[],
  total: number,
  start: number,
  length: number,
) {
  const s = ((start % total) + total) % total;
  const e = s + length;
  ctx.beginPath();
  let started = false;
  const step = Math.max(1.5, total / 400);
  for (let d = s; d <= e; d += step) {
    const p = pointAt(pts, lens, total, d);
    if (!started) {
      ctx.moveTo(p.x, p.y);
      started = true;
    } else ctx.lineTo(p.x, p.y);
  }
  const pEnd = pointAt(pts, lens, total, e);
  ctx.lineTo(pEnd.x, pEnd.y);
  ctx.stroke();
}

function drawLoop(ctx: CanvasRenderingContext2D, pts: Pt[]) {
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
  ctx.closePath();
  ctx.stroke();
}

function buildPaths() {
  const blue0 = stadium(A, B, -ANGLE, CX, CY);
  const gray0 = stadium(A, B, ANGLE, CX, CY);
  const hit = closestHit(blue0, gray0);
  const blue = insertPoint(blue0, hit.p, hit.bi);
  const gray = insertPoint(gray0, hit.p, hit.gi);
  const bIdx = blue.findIndex(
    (p) => Math.abs(p.x - hit.p.x) < 0.01 && Math.abs(p.y - hit.p.y) < 0.01,
  );
  const gIdx = gray.findIndex(
    (p) => Math.abs(p.x - hit.p.x) < 0.01 && Math.abs(p.y - hit.p.y) < 0.01,
  );
  const blueFrom = rotateTo(blue, Math.max(0, bIdx));
  const grayFrom = rotateTo(gray, Math.max(0, gIdx));
  const combined = [...blueFrom, ...grayFrom.slice(1)];
  return { blue, gray, combined };
}

export function LinkFlowLogo({ className }: { className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const { blue, gray, combined } = buildPaths();
    const { lens, total } = cumlen(combined);
    const oneLoop = total / 2;
    const snakeLen = oneLoop * 0.96;

    let raf = 0;
    let start = performance.now();

    const paint = (now: number) => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const scale = Math.min(w, h) / SIZE;
      ctx.translate((w - SIZE * scale) / 2, (h - SIZE * scale) / 2);
      ctx.scale(scale, scale);

      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.miterLimit = 2;

      ctx.strokeStyle = TRACK;
      ctx.lineWidth = STROKE;
      drawLoop(ctx, blue);
      drawLoop(ctx, gray);

      const t = reduce ? 0 : ((now - start) / CYCLE_MS) % 1;
      const d0 = t * total;
      const d1 = d0 + total * 0.5;

      ctx.lineWidth = STROKE;
      ctx.strokeStyle = GRAY;
      drawSubpath(ctx, combined, lens, total, d1, snakeLen);
      ctx.strokeStyle = BLUE;
      drawSubpath(ctx, combined, lens, total, d0, snakeLen);

      if (!reduce) raf = requestAnimationFrame(paint);
    };

    raf = requestAnimationFrame(paint);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <canvas
      ref={ref}
      className={className}
      width={SIZE}
      height={SIZE}
      role="img"
      aria-label="İki halkanın birbirinin hattına geçtiği logo"
    />
  );
}
