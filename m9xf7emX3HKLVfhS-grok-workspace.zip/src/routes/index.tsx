import { createFileRoute } from "@tanstack/react-router";
import { LinkFlowLogo } from "@/components/link-flow-logo";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="flex min-h-dvh items-center justify-center bg-bg">
      <LinkFlowLogo className="h-[min(72vw,320px)] w-[min(72vw,320px)]" />
    </main>
  );
}
