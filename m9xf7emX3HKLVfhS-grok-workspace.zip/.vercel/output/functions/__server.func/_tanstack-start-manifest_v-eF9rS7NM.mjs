//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-eF9rS7NM.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CwjWIUNI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CwjWIUNI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CM9T3849.js"]
	}
} });
//#endregion
export { tsrStartManifest };
